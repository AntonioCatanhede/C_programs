#include <stdio.h>

void pe_print_intvector(int v[], int sz);
void pe_print_chrvector(char v[], int sz);
