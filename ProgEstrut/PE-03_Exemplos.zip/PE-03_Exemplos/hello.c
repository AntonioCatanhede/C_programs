#include <stdio.h>

int main() {
	printf("Tinha que ser Hello World!\n");
	return 0;
}
