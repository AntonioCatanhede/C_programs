#include <stdio.h>

int main() {
	printf(" \n Este é o comando de saída de dados.");
	printf(" \n Este é o número dois: %d.", 2);
	printf(" \n %s está a %d milhões de milhas \n do sol.", "Vênus", 67);
	printf(" \n A letra %c ", 'j');
	printf(" \n Pronuncia-se %s.\n\n", "jota.");

	return 0;
}
