#include <stdio.h>

int main() {
	FILE *fp; char ch;

	fp = fopen("lista_compras.csv", "r");
	if (!fp) {
		printf("O arquivo não pode ser aberto.\n");
		return -3;
	}

	while (!feof(fp)) {
		ch = fgetc(fp);
		if (ch != EOF) {
			printf("%c", ch);
		}
	}

	fclose(fp);
	return 0;
}
